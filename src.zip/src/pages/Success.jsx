export default function Success() {
  return <div className='p-10 text-center text-xl'>Application Submitted</div>
}